import logoFutgestor from "@/assets/logo-futgestor.png";

export const ESCUDO_PADRAO = logoFutgestor;
export const BANNER_PADRAO = ""; // Pode ser adicionado futuramente se necessário
