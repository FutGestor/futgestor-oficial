import { createContext, useContext, useEffect } from "react";
import { useParams, Outlet } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import NotFound from "@/pages/NotFound";
import { LoadingScreen } from "@/components/LoadingScreen";
import { applyTeamTheme } from "@/lib/colors";
import { ESCUDO_PADRAO } from "@/lib/constants";

export interface TeamSlugData {
  id: string;
  nome: string;
  slug: string;
  escudo_url: string | null;
  banner_url: string | null;
  cidade: string | null;
  estado: string | null;
  cores: any;
  invite_code?: string | null;
  owner_contact?: string | null;
  redes_sociais: Record<string, string>;
  bio_config?: {
    text: string | null;
    color: string;
    fontSize: string;
    fontWeight: string;
    textAlign: string;
    fontFamily: string;
    titleColor?: string;
  };
}

interface TeamSlugContextType {
  slug: string;
  team: TeamSlugData;
  basePath: string;
}

const TeamSlugContext = createContext<TeamSlugContextType | null>(null);

export function TeamSlugLayout() {
  const { slug } = useParams<{ slug: string }>();

  const { data: teamData, isLoading, isError } = useQuery({
    queryKey: ["team-by-slug", slug],
    enabled: !!slug,
    retry: 1,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("teams")
        .select("*")
        .eq("slug", slug!)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  useEffect(() => {
    if (slug) {
      localStorage.setItem("lastTeamSlug", slug);
    }
  }, [slug]);

  // Theme is now handled globaly by useTeamConfig


  if (isLoading) {
    return <LoadingScreen />;
  }

  if (isError) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-muted">
        <div className="text-center">
          <h1 className="mb-4 text-2xl font-bold">Erro ao carregar</h1>
          <p className="mb-4 text-muted-foreground">Não foi possível carregar os dados do time.</p>
          <a href="/" className="text-primary underline hover:text-primary/90">Voltar ao início</a>
        </div>
      </div>
    );
  }

  if (!teamData) {
    return <NotFound />;
  }

  const value: TeamSlugContextType = {
    slug: slug!,
    team: {
      id: teamData.id,
      nome: teamData.nome,
      slug: teamData.slug,
      escudo_url: teamData.escudo_url || ESCUDO_PADRAO,
      banner_url: (teamData as any).banner_url || null,
      cidade: (teamData as any).cidade,
      estado: (teamData as any).estado,
      cores: teamData.cores,
      invite_code: teamData.invite_code,
      owner_contact: (teamData as any).owner_contact,
      redes_sociais: (teamData.redes_sociais as Record<string, string>) || {},
      bio_config: (teamData as any).bio_config || null,
    },
    basePath: `/time/${slug}`,
  };

  return (
    <TeamSlugContext.Provider value={value}>
      <Outlet />
    </TeamSlugContext.Provider>
  );
}

export function useTeamSlug() {
  const context = useContext(TeamSlugContext);
  if (!context) {
    throw new Error("useTeamSlug must be used within a TeamSlugLayout");
  }
  return context;
}

export function useOptionalTeamSlug() {
  return useContext(TeamSlugContext);
}
