// Theme toggle removed - app is dark-only
export function ThemeToggle() {
  return null;
}
