import { useOptionalTeamSlug } from "@/hooks/useTeamSlug";
import { useTeamConfig } from "@/hooks/useTeamConfig";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { 
  Bell, 
  Headphones, 
  Trophy, 
  BookOpen, 
  ShieldCheck, 
  Search,
  User,
  LogOut,
  EllipsisVertical
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAvisosNaoLidos } from "@/hooks/useAvisoLeituras";
import { useNotificacoesNaoLidas } from "@/hooks/useNotificacoes";
import { useAuth } from "@/hooks/useAuth";
import { usePlanAccess } from "@/hooks/useSubscription";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { useState } from "react";
import { TeamShield } from "@/components/TeamShield";

export function MobileMenuSheet() {
  const location = useLocation();
  const { team, isLoading: teamLoading } = useTeamConfig();
  const teamSlugValue = team?.slug;
  const basePath = teamSlugValue ? `/time/${teamSlugValue}` : "";
  
  const { data: naoLidos } = useAvisosNaoLidos(team?.id);
  const { data: notificacoesNaoLidas = 0 } = useNotificacoesNaoLidas();
  const { user, profile, isAdmin, isApproved, signOut } = useAuth();
  const navigate = useNavigate();
  const { hasAvisos } = usePlanAccess(team?.id);
  const [open, setOpen] = useState(false);

  const isPlayer = !!profile?.jogador_id && !isAdmin;

  // Menu Items (Inside Sheet)
  const menuItems = teamSlugValue ? [
    ...(hasAvisos ? [{ href: `${basePath}/avisos`, label: "Avisos", icon: Bell }] : []),
    { href: `${basePath}/suporte`, label: "Suporte", icon: Headphones },
    { href: `${basePath}/conquistas`, label: "Arena de Conquistas", icon: Trophy },
    { href: `${basePath}/guia`, label: "Guia", icon: BookOpen },
  ] : [];

  const adminMenuItems = [
    ...(teamSlugValue ? [{ href: `${basePath}/times`, label: "Times", icon: ShieldCheck }] : []),
  ];

  const notificationCount = (naoLidos ?? 0) + notificacoesNaoLidas;

  const handleSignOut = async () => {
    await signOut();
    setOpen(false);
    navigate("/auth");
  };

  // if (!basePath) return null; // Removed this check to allow rendering without team context

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="md:hidden relative h-9 w-9 text-white/90 hover:bg-white/10"
        >
          <EllipsisVertical className="h-5 w-5" />
          {notificationCount > 0 && (
            <span className="absolute top-1 right-1 flex h-2.5 w-2.5 items-center justify-center rounded-full bg-destructive animate-pulse" />
          )}
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="w-[300px] sm:w-[540px] overflow-y-auto bg-black/60 backdrop-blur-3xl border-white/5 text-white shadow-2xl z-[100]">
        <SheetHeader className="text-left mb-8 border-b border-white/10 pb-6">
          <SheetTitle className="flex items-center gap-3">
            <div className="relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-primary/50 to-amber-500/50 rounded-full blur opacity-25 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
              <TeamShield 
                escudoUrl={team?.escudo_url || null} 
                teamName={team?.nome || "FutGestor"} 
                size="md" 
                className="relative border-white/20 shadow-xl"
              />
            </div>
            <div className="flex flex-col">
              <span className="truncate text-xl font-black uppercase tracking-tight leading-none text-white">
                {team?.nome || "FutGestor"}
              </span>
              <span className="text-[10px] text-primary font-black uppercase tracking-widest mt-1 shadow-sm">
                PAINEL DO CLUBE
              </span>
            </div>
          </SheetTitle>
        </SheetHeader>

        <div className="grid gap-2 py-4">
          <p className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 px-2 mb-3">Navegação Principal</p>
          {menuItems.map((item) => {
            const isActive = location.pathname === item.href;
            const Icon = item.icon;
            const showBadge = item.href === `${basePath}/avisos` && notificationCount > 0;

            return (
              <Link
                key={item.href}
                to={item.href}
                onClick={() => setOpen(false)}
                className={cn(
                  "flex items-center gap-4 rounded-xl px-4 py-3 text-sm font-semibold transition-all duration-300",
                  isActive
                    ? "bg-primary text-black shadow-lg shadow-primary/20 scale-[1.02]"
                    : "text-white/70 hover:bg-white/5 hover:text-white"
                )}
              >
                <Icon className={cn("h-5 w-5", isActive ? "stroke-[2.5px]" : "opacity-70")} />
                {item.label}
                {showBadge && (
                  <span className="ml-auto flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-[10px] font-black text-white shadow-lg animate-bounce">
                    {notificationCount > 9 ? "9+" : notificationCount}
                  </span>
                )}
              </Link>
            );
          })}

          {isAdmin && (
            <>
              <div className="my-6 border-t border-white/10 mx-2" />
              <p className="text-[11px] font-black uppercase tracking-[0.2em] text-primary px-2 mb-3 flex items-center gap-2 shadow-sm">
                 <ShieldCheck className="h-3.5 w-3.5" />
                 MÓDULO ADMINISTRATIVO
              </p>
              <div className="grid grid-cols-2 gap-2">
                {adminMenuItems.map((item) => {
                  const isActive = location.pathname === item.href;
                  const Icon = item.icon;

                  return (
                    <Link
                      key={item.href}
                      to={item.href}
                      onClick={() => setOpen(false)}
                      className={cn(
                        "flex flex-col items-center justify-center gap-2 rounded-xl p-4 text-[11px] font-bold transition-all border",
                        isActive
                          ? "bg-white/10 border-primary text-primary shadow-inner shadow-primary/10"
                          : "bg-white/5 border-white/5 text-white/50 hover:bg-white/10 hover:text-white"
                      )}
                    >
                      <Icon className={cn("h-6 w-6 transition-all duration-300", isActive ? "text-primary drop-shadow-[0_0_8px_rgba(5,96,179,0.5)]" : "opacity-50 group-hover:opacity-100")} />
                      {item.label}
                    </Link>
                  );
                })}
              </div>
            </>
          )}

          <div className="my-6 border-t border-white/10 mx-2" />
          <p className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 px-2 mb-3">Sua Conta</p>

          <div className="space-y-1">
            {isApproved && teamSlugValue && !isPlayer && (
              <Link to={`${basePath}/meu-perfil`} onClick={() => setOpen(false)}>
                <Button variant="ghost" className="w-full justify-start gap-4 px-4 h-12 text-white/70 hover:text-white hover:bg-white/5 rounded-xl font-semibold">
                  <User className="h-5 w-5 opacity-70" />
                  Gerenciar Perfil
                </Button>
              </Link>
            )}
            
            {isPlayer && teamSlugValue && (
              <Link to={`${basePath}/meu-perfil`} onClick={() => setOpen(false)}>
                <Button variant="ghost" className="w-full justify-start gap-4 px-4 h-12 text-white/70 hover:text-white hover:bg-white/5 rounded-xl font-semibold">
                  <User className="h-5 w-5 opacity-70" />
                  Minha Área de Atleta
                </Button>
              </Link>
            )}

            <Button variant="ghost" className="w-full justify-start gap-4 px-4 h-12 text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-xl font-bold" onClick={handleSignOut}>
              <LogOut className="h-5 w-5 opacity-70" />
              Encerrar Sessão
            </Button>
          </div>

          <div className="mt-auto pt-8 pb-4 text-center">
            <p className="text-[9px] font-black uppercase tracking-[0.3em] text-white/10">
              FutGestor Pro v2.0
            </p>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
